{
      "dir": "ltr",
      "name": "Big Bass Splash",
      "scope": "./",
      "display": "standalone",
      "start_url": "./pagedirect.php",
      "short_name": "Big Bass Splash",
      "theme_color": "#1f1f1f",
      "description": "🎰 Big Bass Splash – only in the official casino app!  🚀 Download the mobile app now and dive into a premium online casino experience—anytime, anywhere. Fast, secure, and user-friendly, the app gives you uninterrupted gameplay and complete peace of mind.  🎮 Play the hottest slot games: 🔥 Book of Ra – Explore the mysteries of ancient Egyptian temples and uncover hidden treasures! 🎰 Plinko – A legendary classic with thrilling payouts! ☀ Sun of Egypt 3 – Feel the power of the Egyptian sun and hit massive jackpots! 💰 Royal Coins 2 – Gold, bonuses, and royal prizes await you! 🎰 Seven Hot – A timeless slot with blazing hot rewards!  📲 Why choose this app? ✔ Lightning-fast installation – Your casino is just seconds away! ✔ Exclusive bonuses and promotions – Available only in the app! ✔ Instant payouts and secure transactions – Play worry-free! ✔ A huge selection of premium slots and live casino games – Non-stop entertainment! ✔ Smooth performance – Stable, fast gameplay on any device!  🎊 Download, play, and win big with us! Your journey to huge rewards starts here! 🎰💰",
      "orientation": "any",
      "background_color": "#1f1f1f",
      "prefer_related_applications": false,
      "icons": [
        {
          "src": "./icon.png",
          "sizes": "512x512",
          "type": "image/png",
          "purpose": "any maskable"
        }
      ],
      "related_applications": [{
        "platform": "webapp",
        "url": "./manifestdirect.php"
      }],
      "screenshots": [],
      "generated": "",
      "manifest_package": "org.chromium.webapk.test",
      "display_mode": "standalone",
      "version_code": "1",
      "version_name": "1.0",
      "bound_webapk": {
        "runtime_host": "org.chromium.chrome",
        "runtime_host_application_name": "Chromium"
      }
    }